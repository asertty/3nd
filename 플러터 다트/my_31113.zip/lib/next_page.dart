import 'package:flutter/material.dart';

class NextPage extends StatelessWidget {

  NextPage(this.name);
  String name;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text('두번째 페이지'),
      ),
      body: Container(
        color: Colors.red,
        child: Text(name),
      )
    );
  }
}

