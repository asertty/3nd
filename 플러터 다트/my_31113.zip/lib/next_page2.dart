import 'package:flutter/material.dart';
import 'package:my_31113/next_page.dart';

class NextPage2 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('세번째 페이지'),
        ),
        body: Container(
          color: Colors.yellow,

        )
    );
  }
}

