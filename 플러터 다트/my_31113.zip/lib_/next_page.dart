import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NextPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('flutter 대학'),
      ),
      body: Container(
        color: Colors.blueAccent,
      ),
    );

  }
  
}