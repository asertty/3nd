import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NextPage2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(title: Text('대학'),),
    body: Container(
      color: Colors.amberAccent,
      height: 200,
    ),
  );

    throw UnimplementedError();
  }

}