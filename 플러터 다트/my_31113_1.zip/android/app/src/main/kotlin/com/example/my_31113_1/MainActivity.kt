package com.example.my_31113_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
