import 'package:flutter/material.dart';

class ShoppingCartDetail extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox();
  }
}

