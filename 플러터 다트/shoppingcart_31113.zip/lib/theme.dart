import 'package:flutter/material.dart';
import 'package:shoppingcart_31113/constants.dart';

ThemeData theme(){
  return ThemeData(
    primarySwatch: kPrimaryColor,
    scaffoldBackgroundColor: kPrimaryColor,
  );
}