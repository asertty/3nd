import 'package:flutter/material.dart';

const kAccentColor = Color(0xFFFF385C);