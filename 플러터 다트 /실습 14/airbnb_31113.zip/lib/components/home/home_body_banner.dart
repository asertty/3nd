import 'package:flutter/material.dart';
import 'package:airbnb_31113/size.dart';

class HomeBodyBanner extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: gap_m),
      child: Stack(
        children: [
          _buildBannerImage(),
          _buildbannerCaption(),
        ],
      ),
    );
  }

  Widget _buildBannerImage(){
    return SizedBox();
  }
  Widget _buildbannerCaption(){
    return SizedBox();
  }
}
