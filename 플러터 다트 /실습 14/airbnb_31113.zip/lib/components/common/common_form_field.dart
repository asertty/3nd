import 'package:flutter/material.dart';

class CommonFormField extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

