package com.example.recipe_30000_0619

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
