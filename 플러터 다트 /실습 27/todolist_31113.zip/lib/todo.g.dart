// GENERATED CODE - DO NOT MODIFY BY HAND
part of 'todo.dart'; //todo.dart 소스의 일부임을 명시
//part 키워드는 하나의 소스 파일의 코드를 여러 파일로 분할해서 저장할때 사용
//library 키워드로 메인 소스에서 라이브러리를 선언하고 사용할 수 있지만 위와 같이 library 선언없이 사용가능
//분할된 소스코드에서는 part of 키워드를 사용하여 메인 소스의 일부임을 명시해야 함.(part of main.dart)
// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class TodoAdapter extends TypeAdapter<Todo>{
  @override
  final int typeId = 0;

  @override
  Todo read(BinaryReader reader){
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for(int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Todo(
    id: fields[0] as int?,
    title: fields[1] as String,
    dateTime: fields[2] as int,
    isDone: fields[3] as bool,
    );
  }
  @override
  void write(BinaryWriter writer, Todo obj){
    writer
    ..writeByte(4)
    ..writeByte(0)
    ..write(obj.id)
    ..writeByte(1)
    ..write(obj.title)
    ..writeByte(2)
    ..write(obj.dateTime)
    ..writeByte(3)
    ..write(obj.isDone);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) => identical(this, other) || other is TodoAdapter && runtimeType == other.runtimeType && typeId == other.typeId;


}
