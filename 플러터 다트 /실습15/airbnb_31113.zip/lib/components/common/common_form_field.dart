import 'package:flutter/material.dart';
import 'package:airbnb_31113/styles.dart';

class CommonFormField extends StatelessWidget {

  final prefixText;
  final hinText;

  const CommonFormField({required this.prefixText, required this.hinText});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        TextFormField(
          textAlignVertical: TextAlignVertical.bottom,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.only(top: 30, left: 20, bottom: 10),
            hintText: hinText,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: Colors.black,
                width: 2,
              ),
            ),
          ),
        ),
        Positioned(
          top: 8,
          left: 20,
          child: Text(
            prefixText,style: overLine(),
          ),
        ),
      ],
    );
  }
}

