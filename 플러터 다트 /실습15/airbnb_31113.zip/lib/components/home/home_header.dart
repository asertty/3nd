import 'package:flutter/material.dart';
import 'package:airbnb_31113/components/home/home_header_appbar.dart';
import 'package:airbnb_31113/components/home/home_header_form.dart';
import 'package:airbnb_31113/size.dart';

class HomeHeader extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: header_height,
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("background.jpeg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            HomeHeaderAppbar(),
            HomeHeaderForm(),
          ],
        ),
      ),
    );
  }
}

