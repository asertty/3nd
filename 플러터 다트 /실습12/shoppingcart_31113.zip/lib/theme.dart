import 'package:flutter/material.dart';
import 'package:shoppingcart_31113/constants.dart';

ThemeData theme(){
  return ThemeData(
    useMaterial3: false,// 앱바 색상도 바뀌게 하는 거
    primarySwatch: kPrimaryColor,
    scaffoldBackgroundColor: kPrimaryColor,
  );
}