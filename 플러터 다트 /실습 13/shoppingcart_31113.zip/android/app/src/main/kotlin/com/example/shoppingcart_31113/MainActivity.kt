package com.example.shoppingcart_31113

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
