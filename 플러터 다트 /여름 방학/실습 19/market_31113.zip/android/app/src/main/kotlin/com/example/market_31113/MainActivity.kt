package com.example.market_31113

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
