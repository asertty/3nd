import 'package:flutter/material.dart';

class NeighbothoodLifeScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('neighbothoodlifescreen'),
    );
  }
}
