import 'package:flutter/material.dart';

class ChattingScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('chattingscreen'),
    );
  }
}
