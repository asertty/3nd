import 'package:flutter/material.dart';
import 'package:market_31113/models/chat_message.dart';
import '../components/appbar_preferred.dart';
import 'components/chat_container.dart';

class ChattingScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('채팅'),
        bottom: appBerBottomLine(),
      ),
      body: ListView(
        children: List.generate(ChatMessageList.length, (index) => ChatContainer(chatMessage: ChatMessageList[index]),
        ),
      ),
    );
  }
}
