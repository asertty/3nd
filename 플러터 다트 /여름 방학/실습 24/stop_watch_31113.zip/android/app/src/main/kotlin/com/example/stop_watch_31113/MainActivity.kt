package com.example.stop_watch_31113

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
