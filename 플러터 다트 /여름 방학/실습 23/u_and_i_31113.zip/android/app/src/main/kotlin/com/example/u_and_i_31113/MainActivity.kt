package com.example.u_and_i_31113

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
