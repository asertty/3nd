jQuery(document).ready(function(){
    $(".main>li").mouseover(function(){
        $(this).find(".sub").stop().slideDown()
    }).mouseout(function(){
        $(this).find(".sub").stop().slideUp()
    })

    $(".no li:first").click(function(){
        $(".pop").show()
        $(".m").show()
    })
    $("button").click(function(){
        $(".pop").hide()
        $(".m").hide()
    })

    $(".imgs li:gt(0)").hide()
    setInterval(function(){
        $(".imgs li:first").fadeOut().next("li").fadeIn().end().appendTo(".imgs ul")
    },1000)
})